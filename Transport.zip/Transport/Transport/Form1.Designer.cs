﻿namespace Transport
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bt_getTableau = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btReset = new System.Windows.Forms.Button();
            this.btDraw = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.spinCol = new System.Windows.Forms.NumericUpDown();
            this.spinLine = new System.Windows.Forms.NumericUpDown();
            this.arrayData = new System.Windows.Forms.DataGridView();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lbl_wait = new System.Windows.Forms.Label();
            this.btExport = new System.Windows.Forms.Button();
            this.btResoudre = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.zcoinSoloution = new System.Windows.Forms.Label();
            this.solutionCoin = new System.Windows.Forms.DataGridView();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.zcoin = new System.Windows.Forms.Label();
            this.arrayCoin = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.zminLiSolution = new System.Windows.Forms.Label();
            this.SolutionMinLi = new System.Windows.Forms.DataGridView();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.zminili = new System.Windows.Forms.Label();
            this.arrayMinili = new System.Windows.Forms.DataGridView();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.button3 = new System.Windows.Forms.Button();
            this.zminicosolution = new System.Windows.Forms.Label();
            this.solutionMinico = new System.Windows.Forms.DataGridView();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.zminico = new System.Windows.Forms.Label();
            this.arrayMinico = new System.Windows.Forms.DataGridView();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.button4 = new System.Windows.Forms.Button();
            this.ztabsolution = new System.Windows.Forms.Label();
            this.solutionTab = new System.Windows.Forms.DataGridView();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.zminitab = new System.Windows.Forms.Label();
            this.arrayMinTab = new System.Windows.Forms.DataGridView();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.button5 = new System.Windows.Forms.Button();
            this.zbalassolution = new System.Windows.Forms.Label();
            this.solutionBalas = new System.Windows.Forms.DataGridView();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.zbalas = new System.Windows.Forms.Label();
            this.arrayBalas = new System.Windows.Forms.DataGridView();
            this.saveFile = new System.Windows.Forms.SaveFileDialog();
            this.openFile = new System.Windows.Forms.OpenFileDialog();
            this.savePdf = new System.Windows.Forms.SaveFileDialog();
            this.menuStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spinCol)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spinLine)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrayData)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.solutionCoin)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.arrayCoin)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SolutionMinLi)).BeginInit();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.arrayMinili)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.groupBox10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.solutionMinico)).BeginInit();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.arrayMinico)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.groupBox11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.solutionTab)).BeginInit();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.arrayMinTab)).BeginInit();
            this.tabPage5.SuspendLayout();
            this.groupBox12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.solutionBalas)).BeginInit();
            this.groupBox9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.arrayBalas)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.toolStripMenuItem1});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(736, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openToolStripMenuItem,
            this.saveToolStripMenuItem,
            this.toolStripSeparator1,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.fileToolStripMenuItem.Text = "Fichier";
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.openToolStripMenuItem.Text = "Ouvrir";
            this.openToolStripMenuItem.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.saveToolStripMenuItem.Text = "Enregistrer Donnees";
            this.saveToolStripMenuItem.Click += new System.EventHandler(this.saveToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(122, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.exitToolStripMenuItem.Text = "Sortir";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(24, 20);
            this.toolStripMenuItem1.Text = "?";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.aboutToolStripMenuItem.Text = "A propos";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // bt_getTableau
            // 
            this.bt_getTableau.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.bt_getTableau.Enabled = false;
            this.bt_getTableau.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_getTableau.Location = new System.Drawing.Point(413, 89);
            this.bt_getTableau.Name = "bt_getTableau";
            this.bt_getTableau.Size = new System.Drawing.Size(132, 23);
            this.bt_getTableau.TabIndex = 7;
            this.bt_getTableau.Text = "Vérifier les données";
            this.bt_getTableau.UseVisualStyleBackColor = true;
            this.bt_getTableau.Click += new System.EventHandler(this.bt_getTableau_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btReset);
            this.groupBox1.Controls.Add(this.btDraw);
            this.groupBox1.Controls.Add(this.bt_getTableau);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.spinCol);
            this.groupBox1.Controls.Add(this.spinLine);
            this.groupBox1.Controls.Add(this.arrayData);
            this.groupBox1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(12, 27);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(712, 271);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Données";
            // 
            // btReset
            // 
            this.btReset.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btReset.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.btReset.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btReset.Location = new System.Drawing.Point(6, 22);
            this.btReset.Margin = new System.Windows.Forms.Padding(0);
            this.btReset.Name = "btReset";
            this.btReset.Size = new System.Drawing.Size(132, 23);
            this.btReset.TabIndex = 13;
            this.btReset.Text = "Nouveau Tableau";
            this.btReset.UseVisualStyleBackColor = false;
            this.btReset.Click += new System.EventHandler(this.btReset_Click);
            // 
            // btDraw
            // 
            this.btDraw.Enabled = false;
            this.btDraw.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btDraw.Location = new System.Drawing.Point(275, 89);
            this.btDraw.Name = "btDraw";
            this.btDraw.Size = new System.Drawing.Size(132, 23);
            this.btDraw.TabIndex = 12;
            this.btDraw.Text = "Dessiner le tableau";
            this.btDraw.UseVisualStyleBackColor = true;
            this.btDraw.Click += new System.EventHandler(this.btDraw_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(3, 94);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(127, 13);
            this.label2.TabIndex = 11;
            this.label2.Text = "Nombre de la demande";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 64);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "Nombre de l\'offre";
            // 
            // spinCol
            // 
            this.spinCol.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.spinCol.Location = new System.Drawing.Point(136, 92);
            this.spinCol.Name = "spinCol";
            this.spinCol.Size = new System.Drawing.Size(61, 22);
            this.spinCol.TabIndex = 9;
            this.spinCol.ValueChanged += new System.EventHandler(this.spinCol_ValueChanged);
            // 
            // spinLine
            // 
            this.spinLine.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.spinLine.Location = new System.Drawing.Point(136, 62);
            this.spinLine.Name = "spinLine";
            this.spinLine.Size = new System.Drawing.Size(61, 22);
            this.spinLine.TabIndex = 8;
            this.spinLine.ValueChanged += new System.EventHandler(this.spinLine_ValueChanged);
            // 
            // arrayData
            // 
            this.arrayData.AllowUserToAddRows = false;
            this.arrayData.AllowUserToDeleteRows = false;
            this.arrayData.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.arrayData.BackgroundColor = System.Drawing.SystemColors.Control;
            this.arrayData.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.arrayData.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.arrayData.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle13;
            this.arrayData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.arrayData.DefaultCellStyle = dataGridViewCellStyle14;
            this.arrayData.Location = new System.Drawing.Point(6, 118);
            this.arrayData.Name = "arrayData";
            this.arrayData.RowHeadersVisible = false;
            this.arrayData.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
            this.arrayData.Size = new System.Drawing.Size(700, 147);
            this.arrayData.TabIndex = 7;
            this.arrayData.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.arrayData_CellValueChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lbl_wait);
            this.groupBox2.Controls.Add(this.btExport);
            this.groupBox2.Controls.Add(this.btResoudre);
            this.groupBox2.Controls.Add(this.tabControl1);
            this.groupBox2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(12, 304);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(712, 333);
            this.groupBox2.TabIndex = 9;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Solution de base - Solution";
            // 
            // lbl_wait
            // 
            this.lbl_wait.AutoSize = true;
            this.lbl_wait.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_wait.ForeColor = System.Drawing.Color.Green;
            this.lbl_wait.Location = new System.Drawing.Point(136, 25);
            this.lbl_wait.Name = "lbl_wait";
            this.lbl_wait.Size = new System.Drawing.Size(0, 17);
            this.lbl_wait.TabIndex = 11;
            // 
            // btExport
            // 
            this.btExport.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btExport.Enabled = false;
            this.btExport.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btExport.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btExport.Location = new System.Drawing.Point(531, 24);
            this.btExport.Name = "btExport";
            this.btExport.Size = new System.Drawing.Size(175, 23);
            this.btExport.TabIndex = 10;
            this.btExport.Text = "Exporter les résultats (pdf)";
            this.btExport.UseVisualStyleBackColor = true;
            this.btExport.Click += new System.EventHandler(this.btExport_Click);
            // 
            // btResoudre
            // 
            this.btResoudre.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btResoudre.Enabled = false;
            this.btResoudre.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btResoudre.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btResoudre.Location = new System.Drawing.Point(6, 24);
            this.btResoudre.Name = "btResoudre";
            this.btResoudre.Size = new System.Drawing.Size(105, 23);
            this.btResoudre.TabIndex = 9;
            this.btResoudre.Text = "Résoudre";
            this.btResoudre.UseVisualStyleBackColor = true;
            this.btResoudre.Click += new System.EventHandler(this.btResoudre_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(6, 53);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(700, 274);
            this.tabControl1.TabIndex = 8;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox4);
            this.tabPage1.Controls.Add(this.groupBox3);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(692, 248);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Coin Nord-Ouest";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.button1);
            this.groupBox4.Controls.Add(this.zcoinSoloution);
            this.groupBox4.Controls.Add(this.solutionCoin);
            this.groupBox4.Font = new System.Drawing.Font("Segoe UI", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(354, 6);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(331, 235);
            this.groupBox4.TabIndex = 1;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Solution par l\'algorithme de Stepping Stone";
            // 
            // button1
            // 
            this.button1.Enabled = false;
            this.button1.Location = new System.Drawing.Point(250, 205);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 11;
            this.button1.Text = "Voir details";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // zcoinSoloution
            // 
            this.zcoinSoloution.AutoSize = true;
            this.zcoinSoloution.Font = new System.Drawing.Font("Segoe UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zcoinSoloution.Location = new System.Drawing.Point(7, 207);
            this.zcoinSoloution.Name = "zcoinSoloution";
            this.zcoinSoloution.Size = new System.Drawing.Size(35, 21);
            this.zcoinSoloution.TabIndex = 10;
            this.zcoinSoloution.Text = "Z =";
            // 
            // solutionCoin
            // 
            this.solutionCoin.AllowUserToAddRows = false;
            this.solutionCoin.AllowUserToDeleteRows = false;
            this.solutionCoin.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.solutionCoin.BackgroundColor = System.Drawing.SystemColors.Control;
            this.solutionCoin.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.solutionCoin.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.solutionCoin.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle15.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Segoe UI", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.solutionCoin.DefaultCellStyle = dataGridViewCellStyle15;
            this.solutionCoin.Location = new System.Drawing.Point(6, 20);
            this.solutionCoin.Name = "solutionCoin";
            this.solutionCoin.ReadOnly = true;
            this.solutionCoin.RowHeadersVisible = false;
            this.solutionCoin.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
            this.solutionCoin.Size = new System.Drawing.Size(319, 184);
            this.solutionCoin.TabIndex = 9;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.zcoin);
            this.groupBox3.Controls.Add(this.arrayCoin);
            this.groupBox3.Font = new System.Drawing.Font("Segoe UI", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(6, 6);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(342, 235);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Solution de base";
            // 
            // zcoin
            // 
            this.zcoin.AutoSize = true;
            this.zcoin.Font = new System.Drawing.Font("Segoe UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zcoin.Location = new System.Drawing.Point(6, 208);
            this.zcoin.Name = "zcoin";
            this.zcoin.Size = new System.Drawing.Size(35, 21);
            this.zcoin.TabIndex = 9;
            this.zcoin.Text = "Z =";
            // 
            // arrayCoin
            // 
            this.arrayCoin.AllowUserToAddRows = false;
            this.arrayCoin.AllowUserToDeleteRows = false;
            this.arrayCoin.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.arrayCoin.BackgroundColor = System.Drawing.SystemColors.Control;
            this.arrayCoin.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.arrayCoin.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.arrayCoin.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle16.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Segoe UI", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle16.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.arrayCoin.DefaultCellStyle = dataGridViewCellStyle16;
            this.arrayCoin.Location = new System.Drawing.Point(6, 21);
            this.arrayCoin.Name = "arrayCoin";
            this.arrayCoin.ReadOnly = true;
            this.arrayCoin.RowHeadersVisible = false;
            this.arrayCoin.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
            this.arrayCoin.Size = new System.Drawing.Size(330, 184);
            this.arrayCoin.TabIndex = 8;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox8);
            this.tabPage2.Controls.Add(this.groupBox5);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(692, 248);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "MiniLigne";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.button2);
            this.groupBox8.Controls.Add(this.zminLiSolution);
            this.groupBox8.Controls.Add(this.SolutionMinLi);
            this.groupBox8.Font = new System.Drawing.Font("Segoe UI", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox8.Location = new System.Drawing.Point(354, 6);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(331, 235);
            this.groupBox8.TabIndex = 2;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Solution par l\'algorithme de Stepping Stone";
            // 
            // button2
            // 
            this.button2.Enabled = false;
            this.button2.Location = new System.Drawing.Point(250, 205);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 12;
            this.button2.Text = "Voir details";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // zminLiSolution
            // 
            this.zminLiSolution.AutoSize = true;
            this.zminLiSolution.Font = new System.Drawing.Font("Segoe UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zminLiSolution.Location = new System.Drawing.Point(7, 207);
            this.zminLiSolution.Name = "zminLiSolution";
            this.zminLiSolution.Size = new System.Drawing.Size(35, 21);
            this.zminLiSolution.TabIndex = 10;
            this.zminLiSolution.Text = "Z =";
            // 
            // SolutionMinLi
            // 
            this.SolutionMinLi.AllowUserToAddRows = false;
            this.SolutionMinLi.AllowUserToDeleteRows = false;
            this.SolutionMinLi.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.SolutionMinLi.BackgroundColor = System.Drawing.SystemColors.Control;
            this.SolutionMinLi.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.SolutionMinLi.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.SolutionMinLi.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle17.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle17.Font = new System.Drawing.Font("Segoe UI", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle17.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.SolutionMinLi.DefaultCellStyle = dataGridViewCellStyle17;
            this.SolutionMinLi.Location = new System.Drawing.Point(6, 20);
            this.SolutionMinLi.Name = "SolutionMinLi";
            this.SolutionMinLi.ReadOnly = true;
            this.SolutionMinLi.RowHeadersVisible = false;
            this.SolutionMinLi.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
            this.SolutionMinLi.Size = new System.Drawing.Size(319, 184);
            this.SolutionMinLi.TabIndex = 9;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.zminili);
            this.groupBox5.Controls.Add(this.arrayMinili);
            this.groupBox5.Font = new System.Drawing.Font("Segoe UI", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.Location = new System.Drawing.Point(6, 6);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(342, 235);
            this.groupBox5.TabIndex = 1;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Solution de base";
            // 
            // zminili
            // 
            this.zminili.AutoSize = true;
            this.zminili.Font = new System.Drawing.Font("Segoe UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zminili.Location = new System.Drawing.Point(6, 208);
            this.zminili.Name = "zminili";
            this.zminili.Size = new System.Drawing.Size(35, 21);
            this.zminili.TabIndex = 9;
            this.zminili.Text = "Z =";
            // 
            // arrayMinili
            // 
            this.arrayMinili.AllowUserToAddRows = false;
            this.arrayMinili.AllowUserToDeleteRows = false;
            this.arrayMinili.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.arrayMinili.BackgroundColor = System.Drawing.SystemColors.Control;
            this.arrayMinili.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.arrayMinili.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.arrayMinili.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Segoe UI", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle18.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.arrayMinili.DefaultCellStyle = dataGridViewCellStyle18;
            this.arrayMinili.Location = new System.Drawing.Point(6, 21);
            this.arrayMinili.Name = "arrayMinili";
            this.arrayMinili.ReadOnly = true;
            this.arrayMinili.RowHeadersVisible = false;
            this.arrayMinili.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
            this.arrayMinili.Size = new System.Drawing.Size(330, 184);
            this.arrayMinili.TabIndex = 8;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.groupBox10);
            this.tabPage3.Controls.Add(this.groupBox6);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(692, 248);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "MiniColonne";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.button3);
            this.groupBox10.Controls.Add(this.zminicosolution);
            this.groupBox10.Controls.Add(this.solutionMinico);
            this.groupBox10.Font = new System.Drawing.Font("Segoe UI", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox10.Location = new System.Drawing.Point(354, 6);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(331, 235);
            this.groupBox10.TabIndex = 3;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Solution par l\'algorithme de Stepping Stone";
            // 
            // button3
            // 
            this.button3.Enabled = false;
            this.button3.Location = new System.Drawing.Point(250, 205);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 12;
            this.button3.Text = "Voir details";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // zminicosolution
            // 
            this.zminicosolution.AutoSize = true;
            this.zminicosolution.Font = new System.Drawing.Font("Segoe UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zminicosolution.Location = new System.Drawing.Point(7, 207);
            this.zminicosolution.Name = "zminicosolution";
            this.zminicosolution.Size = new System.Drawing.Size(35, 21);
            this.zminicosolution.TabIndex = 10;
            this.zminicosolution.Text = "Z =";
            // 
            // solutionMinico
            // 
            this.solutionMinico.AllowUserToAddRows = false;
            this.solutionMinico.AllowUserToDeleteRows = false;
            this.solutionMinico.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.solutionMinico.BackgroundColor = System.Drawing.SystemColors.Control;
            this.solutionMinico.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.solutionMinico.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.solutionMinico.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle19.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle19.Font = new System.Drawing.Font("Segoe UI", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle19.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle19.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle19.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.solutionMinico.DefaultCellStyle = dataGridViewCellStyle19;
            this.solutionMinico.Location = new System.Drawing.Point(6, 20);
            this.solutionMinico.Name = "solutionMinico";
            this.solutionMinico.ReadOnly = true;
            this.solutionMinico.RowHeadersVisible = false;
            this.solutionMinico.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
            this.solutionMinico.Size = new System.Drawing.Size(319, 184);
            this.solutionMinico.TabIndex = 9;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.zminico);
            this.groupBox6.Controls.Add(this.arrayMinico);
            this.groupBox6.Font = new System.Drawing.Font("Segoe UI", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox6.Location = new System.Drawing.Point(6, 6);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(342, 235);
            this.groupBox6.TabIndex = 1;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Solution de base";
            // 
            // zminico
            // 
            this.zminico.AutoSize = true;
            this.zminico.Font = new System.Drawing.Font("Segoe UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zminico.Location = new System.Drawing.Point(6, 208);
            this.zminico.Name = "zminico";
            this.zminico.Size = new System.Drawing.Size(35, 21);
            this.zminico.TabIndex = 9;
            this.zminico.Text = "Z =";
            // 
            // arrayMinico
            // 
            this.arrayMinico.AllowUserToAddRows = false;
            this.arrayMinico.AllowUserToDeleteRows = false;
            this.arrayMinico.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.arrayMinico.BackgroundColor = System.Drawing.SystemColors.Control;
            this.arrayMinico.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.arrayMinico.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.arrayMinico.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle20.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle20.Font = new System.Drawing.Font("Segoe UI", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle20.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle20.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle20.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle20.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.arrayMinico.DefaultCellStyle = dataGridViewCellStyle20;
            this.arrayMinico.Location = new System.Drawing.Point(6, 21);
            this.arrayMinico.Name = "arrayMinico";
            this.arrayMinico.RowHeadersVisible = false;
            this.arrayMinico.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
            this.arrayMinico.Size = new System.Drawing.Size(330, 184);
            this.arrayMinico.TabIndex = 8;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.groupBox11);
            this.tabPage4.Controls.Add(this.groupBox7);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(692, 248);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "MiniTab";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.button4);
            this.groupBox11.Controls.Add(this.ztabsolution);
            this.groupBox11.Controls.Add(this.solutionTab);
            this.groupBox11.Font = new System.Drawing.Font("Segoe UI", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox11.Location = new System.Drawing.Point(354, 6);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(331, 235);
            this.groupBox11.TabIndex = 3;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Solution par l\'algorithme de Stepping Stone";
            // 
            // button4
            // 
            this.button4.Enabled = false;
            this.button4.Location = new System.Drawing.Point(250, 206);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 12;
            this.button4.Text = "Voir details";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // ztabsolution
            // 
            this.ztabsolution.AutoSize = true;
            this.ztabsolution.Font = new System.Drawing.Font("Segoe UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ztabsolution.Location = new System.Drawing.Point(7, 207);
            this.ztabsolution.Name = "ztabsolution";
            this.ztabsolution.Size = new System.Drawing.Size(35, 21);
            this.ztabsolution.TabIndex = 10;
            this.ztabsolution.Text = "Z =";
            // 
            // solutionTab
            // 
            this.solutionTab.AllowUserToAddRows = false;
            this.solutionTab.AllowUserToDeleteRows = false;
            this.solutionTab.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.solutionTab.BackgroundColor = System.Drawing.SystemColors.Control;
            this.solutionTab.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.solutionTab.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.solutionTab.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle21.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle21.Font = new System.Drawing.Font("Segoe UI", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle21.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle21.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle21.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle21.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.solutionTab.DefaultCellStyle = dataGridViewCellStyle21;
            this.solutionTab.Location = new System.Drawing.Point(6, 20);
            this.solutionTab.Name = "solutionTab";
            this.solutionTab.ReadOnly = true;
            this.solutionTab.RowHeadersVisible = false;
            this.solutionTab.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
            this.solutionTab.Size = new System.Drawing.Size(319, 184);
            this.solutionTab.TabIndex = 9;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.zminitab);
            this.groupBox7.Controls.Add(this.arrayMinTab);
            this.groupBox7.Font = new System.Drawing.Font("Segoe UI", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox7.Location = new System.Drawing.Point(6, 6);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(342, 235);
            this.groupBox7.TabIndex = 1;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Solution de base";
            // 
            // zminitab
            // 
            this.zminitab.AutoSize = true;
            this.zminitab.Font = new System.Drawing.Font("Segoe UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zminitab.Location = new System.Drawing.Point(6, 208);
            this.zminitab.Name = "zminitab";
            this.zminitab.Size = new System.Drawing.Size(35, 21);
            this.zminitab.TabIndex = 9;
            this.zminitab.Text = "Z =";
            // 
            // arrayMinTab
            // 
            this.arrayMinTab.AllowUserToAddRows = false;
            this.arrayMinTab.AllowUserToDeleteRows = false;
            this.arrayMinTab.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.arrayMinTab.BackgroundColor = System.Drawing.SystemColors.Control;
            this.arrayMinTab.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.arrayMinTab.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.arrayMinTab.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle22.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle22.Font = new System.Drawing.Font("Segoe UI", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle22.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle22.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle22.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle22.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.arrayMinTab.DefaultCellStyle = dataGridViewCellStyle22;
            this.arrayMinTab.Location = new System.Drawing.Point(6, 21);
            this.arrayMinTab.Name = "arrayMinTab";
            this.arrayMinTab.RowHeadersVisible = false;
            this.arrayMinTab.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
            this.arrayMinTab.Size = new System.Drawing.Size(330, 184);
            this.arrayMinTab.TabIndex = 8;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.groupBox12);
            this.tabPage5.Controls.Add(this.groupBox9);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(692, 248);
            this.tabPage5.TabIndex = 5;
            this.tabPage5.Text = "Balas Hammer";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.button5);
            this.groupBox12.Controls.Add(this.zbalassolution);
            this.groupBox12.Controls.Add(this.solutionBalas);
            this.groupBox12.Font = new System.Drawing.Font("Segoe UI", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox12.Location = new System.Drawing.Point(354, 6);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(331, 235);
            this.groupBox12.TabIndex = 3;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Solution par l\'algorithme de Stepping Stone";
            // 
            // button5
            // 
            this.button5.Enabled = false;
            this.button5.Location = new System.Drawing.Point(250, 205);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 12;
            this.button5.Text = "Voir details";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // zbalassolution
            // 
            this.zbalassolution.AutoSize = true;
            this.zbalassolution.Font = new System.Drawing.Font("Segoe UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zbalassolution.Location = new System.Drawing.Point(7, 207);
            this.zbalassolution.Name = "zbalassolution";
            this.zbalassolution.Size = new System.Drawing.Size(35, 21);
            this.zbalassolution.TabIndex = 10;
            this.zbalassolution.Text = "Z =";
            // 
            // solutionBalas
            // 
            this.solutionBalas.AllowUserToAddRows = false;
            this.solutionBalas.AllowUserToDeleteRows = false;
            this.solutionBalas.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.solutionBalas.BackgroundColor = System.Drawing.SystemColors.Control;
            this.solutionBalas.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.solutionBalas.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.solutionBalas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle23.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle23.Font = new System.Drawing.Font("Segoe UI", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle23.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle23.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle23.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle23.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.solutionBalas.DefaultCellStyle = dataGridViewCellStyle23;
            this.solutionBalas.Location = new System.Drawing.Point(6, 20);
            this.solutionBalas.Name = "solutionBalas";
            this.solutionBalas.ReadOnly = true;
            this.solutionBalas.RowHeadersVisible = false;
            this.solutionBalas.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
            this.solutionBalas.Size = new System.Drawing.Size(319, 184);
            this.solutionBalas.TabIndex = 9;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.zbalas);
            this.groupBox9.Controls.Add(this.arrayBalas);
            this.groupBox9.Font = new System.Drawing.Font("Segoe UI", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox9.Location = new System.Drawing.Point(6, 6);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(342, 235);
            this.groupBox9.TabIndex = 1;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Solution de base";
            // 
            // zbalas
            // 
            this.zbalas.AutoSize = true;
            this.zbalas.Font = new System.Drawing.Font("Segoe UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zbalas.Location = new System.Drawing.Point(6, 208);
            this.zbalas.Name = "zbalas";
            this.zbalas.Size = new System.Drawing.Size(35, 21);
            this.zbalas.TabIndex = 9;
            this.zbalas.Text = "Z =";
            // 
            // arrayBalas
            // 
            this.arrayBalas.AllowUserToAddRows = false;
            this.arrayBalas.AllowUserToDeleteRows = false;
            this.arrayBalas.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.arrayBalas.BackgroundColor = System.Drawing.SystemColors.Control;
            this.arrayBalas.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.arrayBalas.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.arrayBalas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle24.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle24.Font = new System.Drawing.Font("Segoe UI", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle24.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle24.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle24.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle24.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.arrayBalas.DefaultCellStyle = dataGridViewCellStyle24;
            this.arrayBalas.Location = new System.Drawing.Point(6, 21);
            this.arrayBalas.Name = "arrayBalas";
            this.arrayBalas.RowHeadersVisible = false;
            this.arrayBalas.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
            this.arrayBalas.Size = new System.Drawing.Size(330, 184);
            this.arrayBalas.TabIndex = 8;
            // 
            // saveFile
            // 
            this.saveFile.Filter = "Transport files|*.transp";
            this.saveFile.FileOk += new System.ComponentModel.CancelEventHandler(this.saveFile_FileOk);
            // 
            // openFile
            // 
            this.openFile.Filter = "Transport files|*.transp";
            this.openFile.FileOk += new System.ComponentModel.CancelEventHandler(this.openFile_FileOk);
            // 
            // savePdf
            // 
            this.savePdf.Filter = "PDF files|*.pdf";
            this.savePdf.FileOk += new System.ComponentModel.CancelEventHandler(this.savePdf_FileOk);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(736, 649);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Recherche Opérationnelle - Transport";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spinCol)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spinLine)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrayData)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.solutionCoin)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.arrayCoin)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SolutionMinLi)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.arrayMinili)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.solutionMinico)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.arrayMinico)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.solutionTab)).EndInit();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.arrayMinTab)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.solutionBalas)).EndInit();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.arrayBalas)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.Button bt_getTableau;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btDraw;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown spinCol;
        private System.Windows.Forms.NumericUpDown spinLine;
        private System.Windows.Forms.DataGridView arrayData;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Button btResoudre;
        private System.Windows.Forms.Button btExport;
        private System.Windows.Forms.Button btReset;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.DataGridView arrayCoin;
        private System.Windows.Forms.Label zcoin;
        private System.Windows.Forms.SaveFileDialog saveFile;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label zminili;
        private System.Windows.Forms.DataGridView arrayMinili;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label zminico;
        private System.Windows.Forms.DataGridView arrayMinico;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label zminitab;
        private System.Windows.Forms.DataGridView arrayMinTab;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Label zbalas;
        private System.Windows.Forms.DataGridView arrayBalas;
        private System.Windows.Forms.OpenFileDialog openFile;
        private System.Windows.Forms.Label lbl_wait;
        private System.Windows.Forms.Label zcoinSoloution;
        private System.Windows.Forms.DataGridView solutionCoin;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label zminLiSolution;
        private System.Windows.Forms.DataGridView SolutionMinLi;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Label zminicosolution;
        private System.Windows.Forms.DataGridView solutionMinico;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Label ztabsolution;
        private System.Windows.Forms.DataGridView solutionTab;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Label zbalassolution;
        private System.Windows.Forms.DataGridView solutionBalas;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.SaveFileDialog savePdf;
    }
}

