﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Transport
{
    public partial class Form2 : Form
    {
        private List<int[,]> list;
        int[,] data;
        int line, colonne;
        public Form2(List<int[,]> list, int[,] data, int line, int colonne)
        {
            InitializeComponent();
            this.ShowInTaskbar = false;
            this.list = list;
            this.line = line;
            this.colonne = colonne;
            this.data = data;

            if(list !=null && data!=null)
            affiche();
        }
        private void affiche()
        {
            string str = "";
            richTextBox1.Text = "\n";
            foreach (int[,] tab in list)
            {
                richTextBox1.Text += "\tETAPE " + (list.IndexOf(tab)+1).ToString() + ")\n\n";
                
                for (int i = 0; i < line-1; i++)
                {
                   
                    for (int j = 0; j < colonne-1; j++)
                    {
                        if (tab[i, j] > 0)
                            str += "\t" + tab[i, j].ToString();
                        else
                            str += "\t-";
                    }     
                    richTextBox1.Text += str + "\n\n";
                    str = "";
                }
                richTextBox1.Text += "\tZ = " + Engine.calculZ(data, tab, line - 1, colonne - 1).ToString() + "\n\n\n";
            }
        }
    }
}
