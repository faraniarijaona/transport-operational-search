﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace Transport
{
    public partial class Form1 : Form
    {
        DataTable src = null;
        int line = 1, column = 2;

        int[,] data;

        List<int[,]> etapeCoin;
        List<int[,]> etapeMinLi;
        List<int[,]> etapeMinCo;
        List<int[,]> etapeMinTab;
        List<int[,]> etapeMinBalas;

        #region data4pdf
        string title;
        DataGridView datag;
        DataGridView basic;
        DataGridView solution;
        string z1, z;
        #endregion

        public Form1()
        {
            InitializeComponent();
        }

        private void btDraw_Click(object sender, EventArgs e)
        {
            if (line != 0 || column != 0)
            {
                arrayData.Columns.Clear();
                src = new DataTable();
                int j = 0; int i = 0;
                while (j < column)
                {
                    if (j == 0)
                    {
                        src.Columns.Add(" ");
                    }

                    else if (j == (column - 1))
                    {
                        src.Columns.Add("OFFRE");
                    }
                    else
                    {
                        src.Columns.Add("C" + j);
                    }
                    j++;

                }

                while (i < line)
                {
                    if (i == line - 1)
                    {
                        src.Rows.Add(new object[] { "DEMANDE" });
                    }
                    else
                    {
                        src.Rows.Add(new object[] { "L" + (i + 1) });
                    }
                    i++;
                }

                arrayData.DataSource = src;
            }
            bt_getTableau.Enabled = true;
        }

        private void spinLine_ValueChanged(object sender, EventArgs e)
        {
            line = Convert.ToInt32(spinLine.Value) + 1;
            if (line == 1 || column == 2)
                btDraw.Enabled = false;
            else
                btDraw.Enabled = true;
        }

        private void spinCol_ValueChanged(object sender, EventArgs e)
        {
            column = Convert.ToInt32(spinCol.Value) + 2;
            if (line == 1 || column == 2)
            {
                btDraw.Enabled = false;
            }
            else
            {
                btDraw.Enabled = true;
            }
        }

        private void bt_getTableau_Click(object sender, EventArgs e)
        {
            DataTable k = (DataTable)arrayData.DataSource;
            if (k != null)
            {
                bool isCorrect = true;
                data = new int[k.Rows.Count, k.Columns.Count - 1];
                for (int i = 0; i < k.Rows.Count; i++)
                {
                    for (int j = 1; j < k.Columns.Count; j++)
                    {
                        if (!((i == (k.Rows.Count - 1)) && (j == k.Columns.Count - 1)))
                        {
                            try
                            {
                                data[i, (j - 1)] = Convert.ToInt32(k.Rows[i].ItemArray[j].ToString().Trim());
                                Console.Write(data[i, (j - 1)].ToString() + " ");
                                if (data[i, (j - 1)] <= 0)
                                    isCorrect = false;
                            }
                            catch (Exception ex)
                            {
                                isCorrect = false;
                            }
                        }
                    }
                    Console.WriteLine();
                }

                if (isCorrect)
                {
                    //  MessageBox.Show("Les valeurs sont correctes", "Test de données", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    btResoudre.Enabled = true;

                    ////button1.Enabled = true;
                    ////button2.Enabled = true;
                    ////button3.Enabled = true;
                    ////button4.Enabled = true;
                    ////button5.Enabled = true;
                }
                else
                {
                    MessageBox.Show("Certaines valeurs sont incorrectes", "Test de données", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    btResoudre.Enabled = false;

                    //button1.Enabled = false;
                    //button2.Enabled = false;
                    //button3.Enabled = false;
                    //button4.Enabled = false;
                    //button5.Enabled = false;
                }

            }

        }

        private void btResoudre_Click(object sender, EventArgs e)
        {
            lbl_wait.Text = "Patienter s'il vous plait...";
            #region lesControles

            btExport.Enabled = true;
            btDraw.Enabled = false;
            spinCol.Enabled = false;
            spinLine.Enabled = false;

            #endregion

            #region Basic_Solution
            zcoin.Text = "Z = " + Engine.calculZ(getData(), Engine.CoinNordWest(getData(), line, column - 1, arrayCoin), line, column - 1).ToString();
            zminili.Text = "Z = " + Engine.calculZ(getData(), Engine.MinLine(getData(), line, column - 1, arrayMinili), line, column - 1).ToString();
            zminico.Text = "Z = " + Engine.calculZ(getData(), Engine.MinCol(getData(), line, column - 1, arrayMinico), line, column - 1).ToString();
            zminitab.Text = "Z = " + Engine.calculZ(getData(), Engine.MinTab(getData(), line, column - 1, arrayMinTab), line, column - 1).ToString();
            zbalas.Text = "Z = " + Engine.calculZ(getData(), Engine.BalasHammer(getData(), line, column - 1, arrayBalas), line, column - 1).ToString();
            #endregion

            #region solution_finale
            SteppingStone st = new SteppingStone(Engine.CoinNordWest(getData(), line, column - 1, arrayCoin), getData(), line, column - 1, solutionCoin);
            etapeCoin = st.etape;
            zcoinSoloution.Text = "Z = " + st.zz.ToString();

            st = new SteppingStone(Engine.MinLine(getData(), line, column - 1, arrayMinili), getData(), line, column - 1, SolutionMinLi);
            etapeMinLi = st.etape;
            zminLiSolution.Text = "Z = " + st.zz.ToString();

            st = new SteppingStone(Engine.MinCol(getData(), line, column - 1, arrayMinico), getData(), line, column - 1, solutionMinico);
            etapeMinCo = st.etape;
            zminicosolution.Text = "Z = " + st.zz.ToString();

            st = new SteppingStone(Engine.MinTab(getData(), line, column - 1, arrayMinTab), getData(), line, column - 1, solutionTab);
            etapeMinTab = st.etape;
            ztabsolution.Text = "Z = " + st.zz.ToString();

            st = new SteppingStone(Engine.BalasHammer(getData(), line, column - 1, arrayBalas), getData(), line, column - 1, solutionBalas);
            etapeMinBalas = st.etape;
            zbalassolution.Text = "Z = " + st.zz.ToString();

            #endregion

            btResoudre.Enabled = false;

            button1.Enabled = true;
            button2.Enabled = true;
            button3.Enabled = true;
            button4.Enabled = true;
            button5.Enabled = true;

            lbl_wait.Text = "";
        }

        private void btReset_Click(object sender, EventArgs e)
        {
            spinCol.Enabled = true;
            spinLine.Enabled = true;
            spinCol.Value = 0;
            spinLine.Value = 0;

            bt_getTableau.Enabled = false;
            btResoudre.Enabled = false;
            btExport.Enabled = false;

            ManipFrame.eraseTable(arrayData);
            ManipFrame.eraseTable(arrayCoin);
            ManipFrame.eraseTable(arrayMinili);
            ManipFrame.eraseTable(arrayMinico);
            ManipFrame.eraseTable(arrayMinTab);
            ManipFrame.eraseTable(arrayBalas);

            ManipFrame.eraseTable(solutionBalas);
            ManipFrame.eraseTable(solutionCoin);
            ManipFrame.eraseTable(solutionMinico);
            ManipFrame.eraseTable(SolutionMinLi);
            ManipFrame.eraseTable(solutionTab);

            zcoin.Text = "Z =";
            zcoinSoloution.Text = "Z =";
            zminili.Text = "Z =";
            zminLiSolution.Text = "Z =";
            zminico.Text = "Z =";
            zminicosolution.Text = "Z =";
            zminitab.Text = "Z =";
            ztabsolution.Text = "Z =";
            zbalassolution.Text = "Z =";

            button1.Enabled = false;
            button2.Enabled = false;
            button3.Enabled = false;
            button4.Enabled = false;
            button5.Enabled = false;
        }

        private void arrayData_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            btResoudre.Enabled = false;
            btExport.Enabled = false;

            ManipFrame.eraseTable(arrayCoin);
            ManipFrame.eraseTable(arrayMinili);
            ManipFrame.eraseTable(arrayMinico);
            ManipFrame.eraseTable(arrayMinTab);
            ManipFrame.eraseTable(arrayBalas);

            ManipFrame.eraseTable(solutionBalas);
            ManipFrame.eraseTable(solutionCoin);
            ManipFrame.eraseTable(solutionMinico);
            ManipFrame.eraseTable(SolutionMinLi);
            ManipFrame.eraseTable(solutionTab);

            zcoin.Text = "Z =";
            zcoinSoloution.Text = "Z =";
            zminili.Text = "Z =";
            zminLiSolution.Text = "Z =";
            zminico.Text = "Z =";
            zminicosolution.Text = "Z =";
            zminitab.Text = "Z =";
            ztabsolution.Text = "Z =";
            zbalassolution.Text = "Z =";

            button1.Enabled = false;
            button2.Enabled = false;
            button3.Enabled = false;
            button4.Enabled = false;
            button5.Enabled = false;

        }

        #region saveFile
        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            saveFile.ShowDialog();
        }

        private void saveFile_FileOk(object sender, CancelEventArgs e)
        {
            try
            {
                string dat = Newtonsoft.Json.JsonConvert.SerializeObject(getDataForSave(), Newtonsoft.Json.Formatting.None);
                File.WriteAllText(saveFile.FileName, dat, Encoding.UTF8);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Erreur de l'enregistrement", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        #endregion

        #region openFile
        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            openFile.ShowDialog();
        }

        private void openFile_FileOk(object sender, CancelEventArgs e)
        {
            try
            {
                string dat = File.ReadAllText(openFile.FileName, Encoding.UTF8);
                Newtonsoft.Json.Linq.JArray gett = (Newtonsoft.Json.Linq.JArray)Newtonsoft.Json.JsonConvert.DeserializeObject(dat);

                int lin = gett.Count();
                int cul = gett.First.Count();

                src = new DataTable();
                src.Columns.Add(" ");

                for (int j = 0; j < cul - 1; j++)
                    src.Columns.Add("C" + (j + 1));
                src.Columns.Add("OFFRE");

                for (int i = 0; i < lin; i++)
                {
                    src.Rows.Add("L" + (i + 1));
                    for (int j = 0; j < cul; j++)
                    {
                        src.Rows[i][j + 1] = gett.ElementAt(i).ElementAt(j).ToString();
                    }
                }

                src.Rows[lin - 1][0] = "DEMANDE";

                btReset_Click(null, null);
                arrayData.DataSource = src;

                bt_getTableau.Enabled = true;
                spinCol.Value = cul - 1;
                spinLine.Value = lin - 1;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Erreur de l'ouverture", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }


        }

        #endregion

        #region Obtenir_data_dans_un_tableau
        private int[,] getData()
        {
            DataTable k = (DataTable)arrayData.DataSource;
            data = new int[k.Rows.Count, k.Columns.Count - 1];
            for (int i = 0; i < k.Rows.Count; i++)
            {
                for (int j = 1; j < k.Columns.Count; j++)
                {
                    if (!((i == (k.Rows.Count - 1)) && (j == k.Columns.Count - 1)))
                    {
                        data[i, (j - 1)] = Convert.ToInt32(k.Rows[i].ItemArray[j].ToString().Trim());
                    }
                }

            }

            return data;
        }

        private object[,] getDataForSave()
        {
            DataTable k = (DataTable)arrayData.DataSource;
            object[,] obj = new object[k.Rows.Count, k.Columns.Count - 1];
            for (int i = 0; i < k.Rows.Count; i++)
            {
                for (int j = 1; j < k.Columns.Count; j++)
                {

                    obj[i, (j - 1)] = Convert.ToString(k.Rows[i].ItemArray[j].ToString().Trim());

                }

            }

            return obj;
        }
        #endregion

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            About k = new About(this);
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            new Form2(etapeCoin, getData(), line, column - 1).ShowDialog(this);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            new Form2(etapeMinLi, getData(), line, column - 1).ShowDialog(this);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            new Form2(etapeMinCo, getData(), line, column - 1).ShowDialog(this);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            new Form2(etapeMinTab, getData(), line, column - 1).ShowDialog(this);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            new Form2(etapeMinBalas, getData(), line, column - 1).ShowDialog(this);
        }

        private void btExport_Click(object sender, EventArgs e)
        {
            this.datag = arrayData;

            switch (tabControl1.SelectedIndex)
            {
                case 0:
                    title = "METHODE COIN NORD-OUEST";
                    this.basic = arrayCoin;
                    this.solution = solutionCoin;
                    this.z1 = zcoin.Text;
                    this.z = zcoinSoloution.Text;
                    break;
                case 1:
                     title = "METHODE MINI LIGNE";
                    this.basic = arrayMinili;
                    this.solution = SolutionMinLi;
                    this.z1 = zminili.Text;
                    this.z = zminLiSolution.Text;
                    break;
                case 2:
                     title = "METHODE MINI COLONNE";
                    this.basic = arrayMinico;
                    this.solution = solutionMinico;
                    this.z1 = zminico.Text;
                    this.z = zminicosolution.Text;
                    break;
                case 3:
                    title = "METHODE MINI TAB";
                    this.basic = arrayMinTab;
                    this.solution = solutionTab;
                    this.z1 = zminitab.Text;
                    this.z = ztabsolution.Text;
                    break;
                case 4:
                    title = "METHODE BALAS HAMMER";
                    this.basic = arrayBalas;
                    this.solution = solutionBalas;
                    this.z1 = zbalas.Text;
                    this.z = zbalassolution.Text;
                    break;

            }
            savePdf.ShowDialog();
        }

        private void savePdf_FileOk(object sender, CancelEventArgs e)
        {
            Fson.savePdf(savePdf.FileName, this.title, this.datag, this.basic, this.solution, this.z1, this.z);
        }

    }
}

