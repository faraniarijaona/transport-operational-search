﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Windows.Forms;
using Newtonsoft.Json;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.IO;

namespace Transport
{
    static class Engine
    {
        public static int[,] CoinNordWest(int[,] data, int ligne, int col, DataGridView dt)
        {
            #region formatResult
            DataTable tb = new DataTable();
            tb.Columns.Add(" ");
            for (int l = 0; l < col - 1; l++)
            {
                tb.Columns.Add("C" + (l + 1));
            }
            for (int l = 0; l < ligne - 1; l++)
            {
                tb.Rows.Add("L" + (l + 1));
            }
            #endregion

            int[,] res = new int[ligne, col];
            int i = 0, j = 0;
            while (i < (ligne - 1))
            {
                while (j < (col - 1))
                {

                    int stock = data[i, col - 1], demande = data[ligne - 1, j];
                    if (stock == demande)
                    {
                        res[i, j] = demande;
                        if (demande != 0)
                            tb.Rows[i][j + 1] = demande;
                        data[i, col - 1] = 0; // reste en stock
                        data[ligne - 1, j] = 0; // demande a satisfaire
                        j++;
                        break;
                    }

                    if (stock > demande)
                    {
                        res[i, j] = demande;
                        if (demande != 0)
                            tb.Rows[i][j + 1] = demande;
                        data[i, col - 1] = stock - demande; // reste en stock
                        data[ligne - 1, j] = 0; // demande a satisfaire
                        j++;
                    }

                    if (stock < demande)
                    {
                        res[i, j] = stock;
                        if (stock != 0)
                            tb.Rows[i][j + 1] = stock;
                        data[i, col - 1] = 0; // reste en stock
                        data[ligne - 1, j] = demande - stock; // demande a satisfaire
                        break;
                    }
                }
                i++;
            }

            dt.DataSource = tb;
            return res;
        }

        public static int[,] MinLine(int[,] data, int ligne, int col, DataGridView dt)
        {
            #region formatResult
            DataTable tb = new DataTable();
            tb.Columns.Add(" ");
            for (int l = 0; l < col - 1; l++)
            {
                tb.Columns.Add("C" + (l + 1));
            }
            for (int l = 0; l < ligne - 1; l++)
            {
                tb.Rows.Add("L" + (l + 1));
            }
            #endregion

            int[,] res = new int[ligne, col];
            int i = 0, j;

            while (i < (ligne - 1))
            {
                while (true)
                {
                    j = 0;
                    int ind_min = j, min = 0;
                    while (j < (col - 1))
                    {

                        //Recherche le premier cout minimale, positif
                        ind_min = j;
                        min = data[i, ind_min];
                        if (min > 0)
                        {
                            break;
                        }
                        else
                        {
                            j++;
                        }
                    }

                    while (j < (col - 1))
                    {
                        if ((min > data[i, j]) && (data[i, j] > 0))
                        {
                            ind_min = j;
                            min = data[i, j];
                        }
                        j++;
                    }

                    if (min == -1)
                        break;

                    int stock = data[i, col - 1], demande = data[ligne - 1, ind_min];

                    if (stock == demande)
                    {
                        res[i, ind_min] = demande;
                        if (demande != 0)
                            tb.Rows[i][ind_min + 1] = demande;

                        data[i, ind_min] = -1;

                        data[i, col - 1] = 0;
                        data[ligne - 1, ind_min] = 0;
                        break;
                    }

                    if (stock > demande)
                    {
                        Console.WriteLine("Min = " + min + " io fa miboucle");
                        Console.WriteLine(stock + "==" + demande + " io fa miboucle");
                        res[i, ind_min] = demande;
                        if (demande != 0)
                            tb.Rows[i][ind_min + 1] = demande;

                        data[i, ind_min] = -1;

                        data[i, col - 1] = stock - demande;
                        data[ligne - 1, ind_min] = 0;

                    }

                    if (stock < demande)
                    {
                        res[i, ind_min] = stock;
                        if (stock != 0)
                            tb.Rows[i][ind_min + 1] = stock;

                        data[i, ind_min] = -1;

                        data[i, col - 1] = 0;
                        data[ligne - 1, ind_min] = demande - stock;
                        break;
                    }
                }
                i++;
            }
            dt.DataSource = tb;
            return res;
        }

        public static int[,] MinCol(int[,] data, int ligne, int col, DataGridView dt)
        {
            #region formaResult
            DataTable tb = new DataTable();
            tb.Columns.Add(" ");
            for (int l = 0; l < col - 1; l++)
            {
                tb.Columns.Add("C" + (l + 1));
            }
            for (int l = 0; l < ligne - 1; l++)
            {
                tb.Rows.Add("L" + (l + 1));
            }
            #endregion

            int[,] res = new int[ligne, col];
            int i, j = 0;
            while (j < col - 1)
            {
                while (true)
                {
                    i = 0;
                    int ind_min = i, min = 0;
                    while (i < (ligne - 1))
                    {
                        //Recherche le premier cout minimale, positif d'une colonne
                        ind_min = i;
                        min = data[ind_min, j];
                        if (min > 0)
                        {
                            break;
                        }
                        else
                        {
                            i++;
                        }
                    }

                    while (i < (ligne - 1))
                    {
                        if ((min > data[i, j]) && (data[i, j] > 0))
                        {
                            ind_min = i;
                            min = data[i, j];
                        }
                        i++;
                    }

                    if (min == -1) // si toutes les cases d'une ligne sont deja traite
                        break;

                    int stock = data[ind_min, col - 1], demande = data[ligne - 1, j];

                    if (stock == demande)
                    {
                        res[ind_min, j] = demande;
                        if (demande != 0)
                            tb.Rows[ind_min][j + 1] = demande;

                        data[ind_min, j] = -1;

                        data[ind_min, col - 1] = 0;
                        data[ligne - 1, j] = 0;
                        break;
                    }

                    if (stock > demande)
                    {
                        res[ind_min, j] = demande;
                        if (demande != 0)
                            tb.Rows[ind_min][j + 1] = demande;

                        data[ind_min, j] = -1;

                        data[ind_min, col - 1] = stock - demande;
                        data[ligne - 1, j] = 0;
                        break;
                    }

                    if (stock < demande)
                    {
                        Console.WriteLine("Min = " + min + " io fa miboucle");
                        Console.WriteLine(stock + "==" + demande + " io fa miboucle");
                        res[ind_min, j] = stock;
                        if (stock != 0)
                            tb.Rows[ind_min][j + 1] = stock;

                        data[ind_min, j] = -1;

                        data[ind_min, col - 1] = 0;
                        data[ligne - 1, j] = demande - stock;
                    }
                }
                j++;
            }
            dt.DataSource = tb;
            return res;
        }

        public static int[,] MinTab(int[,] data, int ligne, int col, DataGridView dt)
        {
            #region formatResult
            DataTable tb = new DataTable();
            tb.Columns.Add(" ");
            for (int l = 0; l < col - 1; l++)
            {
                tb.Columns.Add("C" + (l + 1));
            }
            for (int l = 0; l < ligne - 1; l++)
            {
                tb.Rows.Add("L" + (l + 1));
            }
            #endregion

            int[,] res = new int[ligne, col];

            while (true)
            {
                Console.WriteLine("Miditra");
                int i = 0, j, ligne_min = 0, col_min = 0, min = 0;
                while (i < ligne - 1)
                {
                    j = 0;
                    while (j < col - 1)
                    {
                        ligne_min = i;
                        col_min = j;
                        min = data[ligne_min, col_min];
                        if (min > 0)
                        {
                            break;
                        }
                        else
                        {
                            j++;
                        }
                    }
                    if (min > 0)
                    {
                        break;
                    }
                    else
                    {
                        i++;
                    }

                }

                //i =0;
                while (i < ligne - 1)
                {
                    j = 0;
                    while (j < col - 1)
                    {
                        if ((min > data[i, j]) && (data[i, j] > 0))
                        {
                            min = data[i, j];
                            ligne_min = i;
                            col_min = j;
                        }
                        j++;
                    }
                    i++;
                }

                int stock = data[ligne_min, col - 1], demande = data[ligne - 1, col_min];

                Console.WriteLine("demande = " + demande);
                Console.WriteLine("stock = " + stock);
                if (min > 0)
                {
                    if (stock == demande)
                    {
                        res[ligne_min, col_min] = demande;
                        Console.WriteLine("res[" + ligne_min + ", " + col_min + "] = " + res[ligne_min, col_min]);
                        if (demande != 0)
                            tb.Rows[ligne_min][col_min + 1] = demande;

                        data[ligne_min, col_min] = -1;
                        data[ligne_min, col - 1] = 0;
                        data[ligne - 1, col_min] = 0;
                    }

                    if (stock > demande)
                    {
                        res[ligne_min, col_min] = demande;
                        Console.WriteLine("res[" + ligne_min + ", " + col_min + "] = " + res[ligne_min, col_min]);
                        if (demande != 0)
                            tb.Rows[ligne_min][col_min + 1] = demande;

                        data[ligne_min, col_min] = -1;
                        data[ligne_min, col - 1] = stock - demande;
                        data[ligne - 1, col_min] = 0;
                    }

                    if (stock < demande)
                    {
                        res[ligne_min, col_min] = stock;
                        Console.WriteLine("res[" + ligne_min + ", " + col_min + "] = " + res[ligne_min, col_min]);
                        if (stock != 0)
                            tb.Rows[ligne_min][col_min + 1] = stock;

                        data[ligne_min, col_min] = -1;
                        data[ligne_min, col - 1] = 0;
                        data[ligne - 1, col_min] = demande - stock;
                    }
                }
                else
                {
                    break;
                }
            }
            dt.DataSource = tb;
            return res;
        }

        public static int[,] BalasHammer(int[,] data, int ligne, int col, DataGridView dt)
        {
            #region formatResult
            DataTable tb = new DataTable();
            tb.Columns.Add(" ");
            for (int l = 0; l < col - 1; l++)
            {
                tb.Columns.Add("C" + (l + 1));
            }
            for (int l = 0; l < ligne - 1; l++)
            {
                tb.Rows.Add("L" + (l + 1));
            }
            #endregion

            int[,] res = new int[ligne, col];
            int[,] replica = new int[ligne, col];
            //Copy de la valeur entrEe dans une autre table
            for (int i = 0; i < ligne; i++)
            {
                for (int j = 0; j < col; j++)
                {
                    replica[i, j] = data[i, j];
                }
            }

            while (ChercheMax(replica, ligne, col) != null)
            {
                int[] val = ChercheMax(replica, ligne, col);
                int line = val[0] // num ligne du minimale
                        , colonne = val[1]; // num colonne du minimale

                int offre = data[line, col - 1];
                int demande = data[ligne - 1, colonne];

                if (offre == demande)
                {
                    res[line, colonne] = demande;
                    if (demande != 0)
                        tb.Rows[line][colonne + 1] = demande;

                    data[line, col - 1] = 0;//offre
                    data[ligne - 1, colonne] = 0; //demande

                    for (int i = 0; i < col; i++)
                    {
                        //elimination del la ligne numero LINE
                        replica[line, i] = -1;
                    }

                    for (int i = 0; i < ligne; i++)
                    {
                        //elimination de la colonne numero COLONNE
                        replica[i, colonne] = -1;
                    }
                }

                if (offre > demande)
                {
                    res[line, colonne] = demande;
                    if (demande != 0)
                        tb.Rows[line][colonne + 1] = demande;

                    data[line, col - 1] = offre - demande;//offre
                    data[ligne - 1, colonne] = 0; //demande

                    for (int i = 0; i < ligne; i++)
                    {
                        //elimination de la colonne numero COLONNE
                        replica[i, colonne] = -1;
                    }
                }

                if (offre < demande)
                {
                    res[line, colonne] = offre;
                    if (offre != 0)
                        tb.Rows[line][colonne + 1] = offre;
                    data[line, col - 1] = 0;//offre
                    data[ligne - 1, colonne] = demande - offre; //demande

                    for (int i = 0; i < col; i++)
                    {
                        //elimination del la ligne numero LINE
                        replica[line, i] = -1;
                    }
                }

            }
            dt.DataSource = tb;
            return res;
        }

        private static int[] ChercheMax(int[,] array, int line, int column)
        {
            for (int i = 0; i < line - 1; i++)
            {
                // difference sur la colonne
                int min1 = 0, min2 = 0, ind_min1 = 0, ind_min2 = 0;

                while (ind_min1 < column - 1)
                {
                    if (array[i, ind_min1] > 0)
                    {
                        min1 = array[i, ind_min1];
                        ind_min2 = ind_min1 + 1;
                        break;
                    }
                    else
                    {
                        ind_min1++;
                    }
                }

                while (ind_min2 < column - 1)
                {
                    if (array[i, ind_min1] > 0)
                    {
                        min2 = array[i, ind_min2];
                        break;
                    }
                    else
                    {
                        ind_min2++;
                    }
                }

                if (min1 > min2)
                {
                    int permu = min1;
                    min1 = min2;
                    min2 = permu;
                }

                for (int j = (ind_min2 + 1); j < column - 1; j++)
                {
                    if (min1 > min2)
                    {
                        int permu = min1;
                        min1 = min2;
                        min2 = permu;
                    }

                    if (array[i, j] > 0)
                    {
                        if (min1 < 0)
                        {
                            min1 = array[i, j];
                        }
                        else if (min2 < 0)
                        {
                            min2 = array[i, j];
                        }
                        else if (array[i, j] < min1)
                        {
                            min2 = min1;
                            min1 = array[i, j];
                        }
                        else if ((array[i, j] > min1) && (array[i, j] < min2))
                        {
                            min2 = array[i, j];
                        }
                    }
                }
                if (min1 < 0)
                {
                    min1 = 0;
                }
                if (min2 < 0)
                {
                    min2 = 0;
                }

                if (min1 > min2)
                {
                    int permu = min1;
                    min1 = min2;
                    min2 = permu;
                }

                array[i, column - 1] = min2 - min1;
            }

            for (int j = 0; j < column - 1; j++)
            {
                // difference sur la ligne
                int min1 = 0, min2 = 0, ind_min1 = 0, ind_min2 = 0;

                while (ind_min1 < line - 1)
                {
                    if (array[ind_min1, j] > 0)
                    {
                        min1 = array[ind_min1, j];
                        ind_min2 = ind_min1 + 1;
                        break;
                    }
                    else
                    {
                        ind_min1++;
                    }
                }

                while (ind_min2 < line - 1)
                {
                    if (array[ind_min2, j] > 0)
                    {
                        min2 = array[ind_min2, j];
                        break;
                    }
                    else
                    {
                        ind_min2++;
                    }
                }

                if (min1 > min2)
                {
                    int permu = min1;
                    min1 = min2;
                    min2 = permu;
                }

                for (int i = (ind_min2 + 1); i < line - 1; i++)
                {
                    if (min1 > min2)
                    {
                        int permu = min1;
                        min1 = min2;
                        min2 = permu;
                    }

                    if (array[i, j] > 0)
                    {
                        if (min1 < 0)
                        {
                            min1 = array[i, j];
                        }
                        else if (min2 < 0)
                        {
                            min2 = array[i, j];
                        }
                        else if (array[i, j] < min1)
                        {
                            min2 = min1;
                            min1 = array[i, j];
                        }
                        else if ((array[i, j] > min1) && (array[i, j] < min2))
                        {
                            min2 = array[i, j];
                        }
                    }

                    if (min1 < 0)
                    {
                        min1 = 0;
                    }
                    if (min2 < 0)
                    {
                        min2 = 0;
                    }

                    if (min1 > min2)
                    {
                        int permu = min1;
                        min1 = min2;
                        min2 = permu;
                    }
                }
                array[line - 1, j] = min2 - min1;
            }

            //cherche max sur les lignes
            int maxL = array[0, column - 1], lineMax = 0;
            for (int i = 0; i < line - 1; i++)
            {
                if (array[i, column - 1] > 0)
                {
                    if (array[i, column - 1] > maxL)
                    {
                        maxL = array[i, column - 1];
                        lineMax = i;
                    }
                }
            }

            //cherche max sur les colonnes
            int maxC = array[line - 1, 0], colMax = 0;
            for (int i = 0; i < column - 1; i++)
            {
                if (array[line - 1, i] > 0)
                {
                    if (array[line - 1, i] > maxC)
                    {
                        maxC = array[line - 1, i];
                        colMax = i;
                    }
                }
            }

            if (maxC <= 0 && maxL <= 0)
            {
                return null;
            }

            if (maxL > maxC)
            {
                int i = 0, indmin = 0;

                while (i < column - 1)
                {
                    if (array[lineMax, i] > 0)
                    {
                        indmin = i;
                        break;
                    }
                    else
                    {
                        i++;
                    }

                }
                int min = array[lineMax, i];
                while (i < column - 1)
                {
                    if (array[lineMax, i] > 0)
                    {
                        if (array[lineMax, i] < min)
                        {
                            indmin = i;
                            min = array[lineMax, i];
                        }
                    }
                    i++;
                }

                return new int[] { lineMax, indmin };
            }
            else
            {
                int i = 0, indmin = 0;

                while (i < line - 1)
                {
                    if (array[i, colMax] > 0)
                    {
                        indmin = i;
                        break;
                    }
                    else
                    {
                        i++;
                    }
                }

                int min = array[i, colMax];
                while (i < line - 1)
                {
                    if (array[i, colMax] > 0)
                    {
                        if (array[i, colMax] < min)
                        {
                            indmin = i;
                            min = array[i, colMax];
                        }
                    }
                    i++;
                }
                return new int[] { indmin, colMax };

            }
        }

        public static int calculZ(int[,] data, int[,] coeff, int ligne, int colonne)
        {
            int somme = 0;
            for (int i = 0; i < ligne; i++)
            {
                for (int j = 0; j < colonne; j++)
                {
                    if (coeff[i, j] > 0)
                        somme = somme + data[i, j] * coeff[i, j];
                }
            }
            return somme;
        }

        public static int[,] arrayCopy(int[,] src, int line, int column)
        {
            int[,] temp = new int[line, column];
            for (int i = 0; i < line; i++)
            {
                for (int j = 0; j < column; j++)
                {
                    temp[i, j] = src[i, j];
                }
            }
            return temp;
        }
    }

    static class ManipFrame
    {
        public static void eraseTable(DataGridView dt)
        {
            DataTable table = (DataTable)dt.DataSource;
            if (table != null)
            {
                table.Rows.Clear();
                table.Columns.Clear();
            }
        }

        public static int[,] getData(DataGridView dt)
        {
            DataTable k = (DataTable)dt.DataSource;
            int[,] res = new int[k.Rows.Count, k.Columns.Count - 1];

            for (int i = 0; i < k.Rows.Count; i++)
            {
                for (int j = 0; j < k.Columns.Count - 1; j++)
                {
                    if ((i != k.Rows.Count - 1) && (j != k.Columns.Count - 2))
                        res[i, j] = Convert.ToInt32(k.Rows[i].ItemArray[j + 1].ToString());
                }
                Console.WriteLine(" ");
            }
            return res;
        }

        public static Boolean copyArray(int[,] source, int[,] destination, int nbL, int nbC)
        {
            try
            {
                destination = new int[nbL, nbC];
                for (int i = 0; i < nbL; i++)
                {
                    for (int j = 0; j < nbC; j++)
                    {
                        destination[i, j] = source[i, j];
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }

        }
    }

    class Fson
    {
        public static void savePdf(string filepath, string title, DataGridView data, DataGridView basic, DataGridView solution, string z1, string z )
        {
            Document doc = new Document(PageSize.A4,50f, 50f, 80f, 10f);
            
            MemoryStream memoryStream = new System.IO.MemoryStream();

            PdfWriter writer = PdfWriter.GetInstance(doc, memoryStream);
            doc.Open();

            doc.Add(new Phrase("\t"+title+"\n\n", FontFactory.GetFont("Arial", 14, Font.BOLD, Color.BLACK)));
            doc.Add(new Phrase());
            doc.Add(new Phrase());

            doc.Add(new Phrase("Données", FontFactory.GetFont("Arial", 12, Font.BOLD, Color.BLACK)));
            doc.Add(write(data));
            doc.Add(new Phrase());

            doc.Add(new Phrase("\n\nSolution de Base", FontFactory.GetFont("Arial", 12, Font.BOLD, Color.BLACK)));
            doc.Add(write(basic));
            doc.Add(new Phrase());
            doc.Add(new Phrase(z + "\n\n", FontFactory.GetFont("Arial", 12, Font.BOLD, Color.BLACK)));
            doc.Add(new Phrase());

            doc.Add(new Phrase("Solution finale", FontFactory.GetFont("Arial", 12, Font.BOLD, Color.BLACK)));
            doc.Add(write(solution));
            doc.Add(new Phrase());

            doc.Add(new Phrase(z, FontFactory.GetFont("Arial", 12, Font.BOLD, Color.BLACK)));

            doc.Close();
            File.WriteAllBytes(filepath, memoryStream.ToArray());
            memoryStream.Close();
        }

        private static PdfPTable write(DataGridView dt)
        {
            Font NormalFont = FontFactory.GetFont("Arial", 12, Font.NORMAL, Color.BLACK);
            DataTable tb = (DataTable)dt.DataSource;
            PdfPTable table = new PdfPTable(tb.Columns.Count);

            foreach (DataColumn k in tb.Columns)
                table.AddCell(new Phrase(k.ColumnName, NormalFont));
            foreach(DataRow rw in tb.Rows)
                for(int j=0; j<tb.Columns.Count; j++)
                    table.AddCell(new Phrase(rw.ItemArray[j].ToString(), NormalFont));

            return table;
        }
    }
}
