﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data;

namespace Transport
{
    class SteppingStone
    {
        int[,] aTransforme; //colonne - 1
        int[,] data; //  colonne
        int line;
        int colonne;

        public int[,] res;
        public int zz;
        public List<int[,]> etape;

        private List<Case> getChemin;

        public SteppingStone(int[,] aTransforme, int[,] data, int line, int colonne, DataGridView dt)
        {
            this.aTransforme = aTransforme;
            this.data = data;
            this.line = line;
            this.colonne = colonne;
            etape = new List<int[,]>();
            res = Steppingstone(data, aTransforme, line, colonne, dt);
        }



        private int[,] tableau_sans_od(int[,] data, int ligne, int colonne)
        {

            int[,] temp = new int[ligne - 1, colonne - 1];
            for (int i = 0; i < ligne - 1; i++)
            {
                for (int j = 0; j < colonne - 1; j++)
                {
                    temp[i, j] = data[i, j];
                }
            }
            return temp;

        }

        private int[,] Steppingstone(int[,] t_origine, int[,] t_modifie, int nb_ligne, int nb_col, DataGridView dt)
        {

            int[,] data = tableau_sans_od(t_origine, nb_ligne, nb_col);
            int[,] t_cout = tableau_sans_od(t_modifie, nb_ligne, nb_col);
            nb_ligne -= 1;
            nb_col -= 1;

            List<Case> list_case_negative;
            List<int> list_cout_negatif;

            do
            {
                etape.Add(Engine.arrayCopy(t_cout, nb_ligne, nb_col));
                for (int i = 0; i < nb_ligne; i++)
                {
                    for (int j = 0; j < nb_col; j++)
                    {

                        if (t_cout[i, j] == 0)
                        {
                            List<Case> temp = new List<Case>();
                            temp.Add(new Case(i, j));

                            List<Case> chemin_temp = chemins(t_cout, nb_ligne, nb_col, true, temp);

                            if (chemin_temp.Count == 0)
                            {
                                t_cout[i, j] = -1;
                            }

                        }

                    }
                }

                list_case_negative = new List<Case>();
                list_cout_negatif = new List<int>();

                for (int i = 0; i < nb_ligne; i++)
                {
                    for (int j = 0; j < nb_col; j++)
                    {

                        if (t_cout[i, j] == 0)
                        {
                            List<Case> temp = new List<Case>();
                            temp.Add(new Case(i, j));

                            int c = CoutUnitaireChemin(data, chemins(t_cout, nb_ligne, nb_col, true, temp));
                            if (c < 0)
                            {
                                list_case_negative.Add(new Case(i, j));
                                list_cout_negatif.Add(c);
                            }
                        }

                    }
                }

                if (list_case_negative.Count != 0)
                {

                    int indice = 0, min = 0;

                    for (int i = 0; i < list_cout_negatif.Count; i++)
                    {

                        List<Case> ch_negatif = new List<Case>();
                        ch_negatif.Add(list_case_negative.ElementAt(i));
                        int t = list_cout_negatif.ElementAt(i) * quantiteADetourne(t_cout, nb_ligne, nb_col,
                                chemins(t_cout, nb_ligne, nb_col, true, ch_negatif));
                        if (t < min)
                        {
                            indice = i;
                            min = t;

                        }
                    }

                    // System.out.println(indice + " " +
                    // list_case_negative.ElementAt(indice).printCase());
                    List<Case> temp_2 = new List<Case>();
                    temp_2.Add(list_case_negative.ElementAt(indice));

                    List<Case> chemin = chemins(t_cout, nb_ligne, nb_col, true, temp_2);
                    //printChemin(chemin);
                    // System.out.println(quantiteADetourne(t_cout, nb_ligne,
                    // nb_col, chemin));
                    t_cout = detourneQte(t_cout, chemin, nb_ligne, nb_col,
                            quantiteADetourne(t_cout, nb_ligne, nb_col, chemin));
                    // PrintTab(t, 4, 6);

                }

            } while (list_case_negative.Count != 0);

            zz = z(data, t_cout, nb_ligne, nb_col);

            DataTable tb = new DataTable();
            tb.Columns.Add(" ");
            for (int l = 0; l < nb_col; l++)
            {
                tb.Columns.Add("C" + (l + 1));
            }
            for (int l = 0; l < nb_ligne; l++)
            {
                tb.Rows.Add("L" + (l + 1));
            }

            for (int i = 0; i < nb_ligne; i++)
                for (int j = 0; j < nb_col; j++)
                    if (t_cout[i, j] > 0)
                        tb.Rows[i][j + 1] = t_cout[i, j];

            dt.DataSource = tb;
            return t_cout;
        }

        private List<Case> chemins(int[,] t_cout, int nb_ligne, int nb_colonne, Boolean ligne, List<Case> depart)
        {
            getChemin = new List<Case>();
            boucleChemin(t_cout, nb_ligne, nb_colonne, ligne, depart);
            return copyList(getChemin);
        }

        private void boucleChemin(int[,] t_cout, int nb_ligne, int nb_colonne, Boolean ligne, List<Case> depart)
        {

            Case case_depart = depart.ElementAt(0);
            Case dernier = depart.ElementAt(depart.Count - 1);

            if (ligne)
            {

                for (int i = 0; i < nb_colonne; i++)
                {
                    if (t_cout[dernier.get_l(), i] != 0 && i != dernier.get_c())
                    {
                        List<Case> temp = copyList(depart);
                        temp.Add(new Case(dernier.get_l(), i));
                        boucleChemin(t_cout, nb_ligne, nb_colonne, false, temp);
                    }
                }

            }
            else
            {

                for (int i = 0; i < nb_ligne; i++)
                {
                    if (case_depart.isEqual(new Case(i, dernier.get_c())))
                    {
                        getChemin = depart;
                    }

                    if (t_cout[i, dernier.get_c()] != 0 && i != dernier.get_l())
                    {
                        List<Case> temp = copyList(depart);
                        temp.Add(new Case(i, dernier.get_c()));
                        boucleChemin(t_cout, nb_ligne, nb_colonne, true, temp);
                    }
                }

            }

        }

        private int CoutUnitaireChemin(int[,] data, List<Case> lc)
        {
            int somme = 0;

            somme = data[lc.ElementAt(0).get_l(), lc.ElementAt(0).get_c()];
            int i = 1, signe = 1;

            // System.out.print(data[lc.ElementAt(0).get_l(),lc.ElementAt(0).get_c()]);
            while (i < lc.Count)
            {

                signe *= -1;

                somme += data[lc.ElementAt(i).get_l(), lc.ElementAt(i).get_c()] * signe;
                // System.out.print(" + " +
                // data[lc.ElementAt(i).get_l(),lc.ElementAt(i).get_c()] * signe);
                i++;
            }

            // System.out.print(" = " + somme + "\n");
            return somme;
        }

        private int[,] detourneQte(int[,] t_cout, List<Case> c, int nb_ligne, int nb_colonne, int qte_a_detourne)
        {

            int signe = -1;

            if (qte_a_detourne != -1)
            {
                for (int i = 0; i < c.Count; i++)
                {
                    signe *= -1;

                    if (t_cout[c.ElementAt(i).get_l(), c.ElementAt(i).get_c()] != -1)
                    {
                        t_cout[c.ElementAt(i).get_l(), c.ElementAt(i).get_c()] = t_cout[c.ElementAt(i).get_l(), c.ElementAt(i).get_c()]
                                + (signe * qte_a_detourne);
                    }
                    else
                    {
                        t_cout[c.ElementAt(i).get_l(), c.ElementAt(i).get_c()] = qte_a_detourne;
                    }

                }
            }
            else
            {
                t_cout[c.ElementAt(0).get_l(), c.ElementAt(0).get_c()] = -1;
                for (int i = 1; i < c.Count; i++)
                {
                    if (t_cout[c.ElementAt(i).get_l(), c.ElementAt(i).get_c()] == -1)
                    {
                        t_cout[c.ElementAt(i).get_l(), c.ElementAt(i).get_c()] = 0;
                    }
                }
            }

            return t_cout;

        }

        private int quantiteADetourne(int[,] t_cout, int nb_ligne, int nb_col, List<Case> chemin)
        {

            int qte_a_detourne = t_cout[chemin.ElementAt(1).get_l(), chemin.ElementAt(1).get_c()];

            for (int i = 3; i < chemin.Count; i += 2)
            {

                if (t_cout[chemin.ElementAt(i).get_l(), chemin.ElementAt(i).get_c()] < qte_a_detourne)
                {
                    qte_a_detourne = t_cout[chemin.ElementAt(i).get_l(), chemin.ElementAt(i).get_c()];
                }

            }

            return qte_a_detourne;
        }

        private List<Case> copyList(List<Case> l)
        {
            List<Case> temp = new List<Case>();

            for (int i = 0; i < l.Count; i++)
            {
                temp.Add(l.ElementAt(i));
            }
            return temp;
        }

        private int z(int[,] data, int[,] t_cout, int nb_ligne, int nb_col)
        {
            int somme = 0;

            for (int i = 0; i < nb_ligne; i++)
            {
                for (int j = 0; j < nb_col; j++)
                {

                    if (t_cout[i, j] != 0 && t_cout[i, j] != -1)
                    {
                        somme += t_cout[i, j] * data[i, j];
                    }
                    else if (t_cout[i, j] == -1)
                    {

                    }

                }
            }
            return somme;
        }

    }
}
